<?php

$jsonString = $_POST['data'];
$class = $_POST['class'];

		$myFile = "class/".$class."/notif.json";
		if (!file_exists("class/".$class)) {
			mkdir("class/".$class, 0777, true);
		}
		$fh = fopen($myFile, 'a') or die("can't open file");
		$data = ",".$jsonString;
		fwrite($fh, $data);
		fclose($fh);
   

header('Location:pushClass.php?class='.$class.'&msg=New%20class%20notification%20received!!');
?>