<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'eurekefk_prt');
define('DB_PASSWORD', 'rootprt');
define('DB_DATABASE', 'eurekefk_sonam');
$connection = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>
