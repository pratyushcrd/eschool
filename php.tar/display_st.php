
<?php
$enter = false;
if(isset($_POST['user'])&&isset($_POST['pass']))
  if($_POST['user']="eureka11"&&$_POST['pass']="eureka22")
   $enter = true;
  else
   die('incorrect username or password');

?>


<!DOCTYPE html>
<html>
<head>
<style>
<?php 
if($enter)
echo "form{visibility:hidden;}";
?>


table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 2px;
}
</style>
</head>
<body>


<form action="display_st.php" class="login" method="post">
Username : <input name="user" type="input"></input><br>
Password : <input name="pass" type="password"></input><br>
<input type="submit" value="submit"></input>
</form>

<table border="1" style="width:100%">


<?php

if(!$enter)
die('Please enter username and pass');    

 require('connect_st.php');

$rows = mysql_query("select * from studentsdb");
if ($rows) {
    $header = true;
    while ($record = mysql_fetch_assoc($rows)) {
        if ($header) {
            echo '<tr>';
            foreach (array_keys($record) AS $col) {
				
                 echo '<td>'.htmlspecialchars($col).'</td> ';
				
			}
            echo '</tr>';
            $header = false;
        }
        echo '<tr>';
        foreach (array_values($record) AS $col) {
            echo '<td>'.htmlspecialchars($col).'</td> ';
        }
        echo '</tr>';
    }
}

?>
</table>
</body>
</html>