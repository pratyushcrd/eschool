<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 15px;
}
</style>
</head>
<body>
<table border="1" style="width:100%">
<?php

 require('connect_st.php');

$rows = mysql_query("select * from teachersdb");
if ($rows) {
    $header = true;
    while ($record = mysql_fetch_assoc($rows)) {
		$i = 0;
		$j = 0;
        if ($header) {
            echo '<tr>';
            foreach (array_keys($record) AS $col) {
				++$i;
				if($col!="pass"){
                 echo '<td>'.htmlspecialchars($col).'</td> ';
				 $k = $i-2;
				}
			}
            echo '</tr><br>';
            $header = false;
        }
        echo '<tr>';
        foreach (array_values($record) AS $col) {
			++$j;
			if($j!=$k)
            echo '<td>'.htmlspecialchars($col).'</td> ';
        }
        echo '</tr><br>';
    }
}

?>
</table>
</body>
</html>