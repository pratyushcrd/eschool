<!DOCTYPE html>
<html>
<head>
<title>Student Information Enter</title>
</head>
<body>


<form method="post" action="submit.php">
<br>Name:<input type="text" name="name">
<br>Class:<input type="text" name="class">
<br>Password:<input type="text" name="pass">
<br>Roll:<input type="text" name="roll">
<br>Username:<input type="text" name="user">
<input type="submit">
</form>

</body>
</html>

