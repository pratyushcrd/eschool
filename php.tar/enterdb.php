<?php
 require('connect_st.php');

    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < 6; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    $characters1 = '0123456789';
    $charactersLength1 = strlen($characters);
    $randomString1 = '';
    for ($i = 0; $i < 10; $i++) {
        $randomString1 .= $characters1[rand(0, $charactersLength1 - 1)];
    }

$query="INSERT INTO studentsdb (id,stid, name, sex, dob, doa, father, mother, class, location, pass, phone, email, section, reg, roll) 
VALUES
(NULL,'$_POST[stid]', '$_POST[name]', '$_POST[sex]', '$_POST[dob]', '$_POST[doa]', '$_POST[father]', '$_POST[mother]', '$_POST[class]', '$_POST[location]', '$randomString', '$_POST[phone]', '$_POST[email]', '$_POST[section]', '$randomString1', '$_POST[roll]')";

$result = mysql_query($query) or die(mysql_error());
?>Successfully Entered <a href="enterst.html">Go back</a>