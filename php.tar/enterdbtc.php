<?php
 require('connect_st.php');

if (!file_exists("teachers/".$_POST['email'])) {
			mkdir("teachers/".$_POST['email'], 0777, true);
		}
		
		$myFile = "teachers/".$_POST['email']."/class.json";
		$fh = fopen($myFile, 'w') or die("can't open file");
		fwrite($fh, $_POST['auth']);
		fclose($fh);
	echo "Json file edited \"teachers/".$_POST['email']."\"\n<br>";
$query="INSERT INTO teachersdb (id, name, location, pass, email, des)
VALUES
(NULL,'$_POST[name]', '$_POST[location]', '$_POST[pass]', '$_POST[email]', '$_POST[desg]')";
$result = mysql_query($query) or die(mysql_error());
?>Successfully Entered <a href="enterst.html">Go back</a>