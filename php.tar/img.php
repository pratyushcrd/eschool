<?php
    // Get image string posted from Android App
    $base=$_REQUEST['image'];
    $base2=$_REQUEST['thumb'];
    // Get file name posted from Android App
    $filename = $_REQUEST['filename'];
    $cls = $_POST['class'];
	$tit = $_REQUEST['teacher'];
	$title = $_REQUEST['title'];
    // Decode Image
    $binary=base64_decode($base);
    $binary2=base64_decode($base2);
    header('Content-Type: bitmap; charset=utf-8');
    // Images will be saved under 'www/imgupload/uplodedimages' folder
    // Create File
	$i=0;
	while(file_exists("class/".$cls."/img/".$i.$filename)||file_exists("class/".$cls."/thumb/".$i.$filename)){
		++$i;
	}
	$filename = $i.$filename;
	if (!file_exists("class/".$cls)) {
		mkdir("class/".$cls, 0777, true);
	}
	if (!file_exists("class/".$cls."/img/")) {
		mkdir("class/".$cls."/img/", 0777, true);
	}
	if (!file_exists("class/".$cls."/thumb/")) {
		mkdir("class/".$cls."/thumb/", 0777, true);
	}
	$file = fopen("class/".$cls."/img/".$filename, 'wb');
	fwrite($file, $binary);
    fclose($file);
	
	$file = fopen("class/".$cls."/thumb/".$filename, 'wb');
	fwrite($file, $binary2);
    fclose($file);
	
	$date = date("D M d, Y G:i");
	$myFile = "class/".$cls."/gallery.json";
		$fh = fopen($myFile, 'a+') or die("can't open file");
		$arr = array("text"=>$tit."\n".$date,"title"=>$title,"url"=>"thumb/".$filename);
		$data = json_encode($arr);
		$data = ",".$data;
		fwrite($fh, $data);
	
	
	
	
	
	
    echo 'success';
?>