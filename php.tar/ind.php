<?php
//ini_set("display_errors",1);
require_once 'excel_reader2.php';
require_once 'db.php';

$data = new Spreadsheet_Excel_Reader("example.xls");

echo "Total Sheets in this xls file: ".count($data->sheets)."<br /><br />";

$html="<table border='1'>";
for($i=0;$i<count($data->sheets);$i++) // Loop to get all sheets in a file.
{	
	if(count($data->sheets[$i][cells])>0) // checking sheet not empty
	{
		echo "Sheet $i:<br /><br />Total rows in sheet $i  ".count($data->sheets[$i][cells])."<br />";
		for($j=2;$j<=count($data->sheets[$i][cells]);$j++) // loop used to get each row of the sheet
		{ 
			$html.="<tr>";
			for($k=1;$k<=count($data->sheets[$i][cells][$j]);$k++) // This loop is created to get data in a table format.
			{
				$html.="<td>";
				$html.=$data->sheets[$i][cells][$j][$k];
				$html.="</td>";
			}
			
			$roll= mysqli_real_escape_string($connection,$data->sheets[$i][cells][$j][10]);
			$name= mysqli_real_escape_string($connection,$data->sheets[$i][cells][$j][2]);
			$section = mysqli_real_escape_string($connection,$data->sheets[$i][cells][$j][8]);
			$gender = mysqli_real_escape_string($connection,$data->sheets[$i][cells][$j][6]);
			$number = mysqli_real_escape_string($connection,$data->sheets[$i][cells][$j][3]);
			$father = mysqli_real_escape_string($connection,$data->sheets[$i][cells][$j][4]);
			$mother = mysqli_real_escape_string($connection,$data->sheets[$i][cells][$j][5]);
			$std = mysqli_real_escape_string($connection,$data->sheets[$i][cells][$j][7]);
			$reg = mysqli_real_escape_string($connection,$data->sheets[$i][cells][$j][9]);

        $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($l = 0; $l < 6; $l++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    $comp = preg_split('/ +/', $name);
    $stid=$comp[0].$reg[3].$reg[4];
	echo $stid;
			$query = "INSERT INTO `eurekefk_sonam`.`studentsdb` (`stid`, `name`, `sex`, `dob`, `doa`, `father`, `mother`, `class`, `location`, `pass`, `phone`, `email`, `section`, `reg`, `roll`) VALUES ('$stid', '$name', '$gender', '', '', '$father', '$mother', '$std', '', '$randomString', '$number', '', '$section', '$reg', '$roll')";
			
			mysqli_query($connection,$query);
			$html.="</tr>";

		}
	}
	
}
$html.="</table>";
echo $html;
echo "<br />Data Inserted in dababase";
?>