<?php
	
// Push The notification with parameters
require_once('PushBots.class.php');
$pb = new PushBots();
// Application ID
$appID = '5594f55d1779596e548b4568';
// Application Secret
$appSecret = '3ed168b57fe3a0d92619f90838cb4628';
$pb->App($appID, $appSecret);
 
// Notification Settings
$pb->Alert($_GET['msg']);
$pb->Platform(array(0,1));

$tags = array($_GET['class']);
$pb->Tags($tags);

$pb->Push();
?>success