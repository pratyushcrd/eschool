<?php

$jsonString = $_POST['data'];
$tnm = $_POST['tnm'];

$jsonArr = json_decode($jsonString, true);

while($item = array_shift($jsonArr))
{
		$myFile = "students/".$item['reg']."/marks.json";
		if (!file_exists("students/".$item['reg'])) {
			mkdir("students/".$item['reg'], 0777, true);
		}
		$fh = fopen($myFile, 'a') or die("can't open file");
		$arr = array("y"=>$item['y'],"m"=>$item['m'],"d"=>$item['d'],"sc"=>$item['marks'],"nm"=>$tnm);
		$data = json_encode($arr);
		$data = ",".$data;
		fwrite($fh, $data);
		$class = $item['c'];
		fclose($fh);
   
}
header('Location:pushClass.php?class='.$class.'&msg=Check%20your%20test%20marks!!');
?>