-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 16, 2015 at 02:44 PM
-- Server version: 5.5.40-36.1
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `eurekefk_sonam`
--

-- --------------------------------------------------------

--
-- Table structure for table `Feedback`
--

CREATE TABLE IF NOT EXISTS `Feedback` (
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `subject` text COLLATE utf8_unicode_ci NOT NULL,
  `message` varchar(300) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `studentsdb`
--

CREATE TABLE IF NOT EXISTS `studentsdb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stid` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `sex` varchar(1) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `doa` varchar(30) NOT NULL,
  `father` varchar(30) NOT NULL,
  `mother` varchar(30) NOT NULL,
  `class` varchar(5) NOT NULL,
  `location` varchar(30) NOT NULL,
  `pass` varchar(60) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `section` varchar(30) NOT NULL,
  `reg` int(20) NOT NULL,
  `roll` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stid` (`stid`),
  UNIQUE KEY `reg` (`reg`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=731 ;

--
-- Dumping data for table `studentsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `teachersdb`
--

CREATE TABLE IF NOT EXISTS `teachersdb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `des` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=502 ;

--
-- Dumping data for table `teachersdb`
--

INSERT INTO `teachersdb` (`id`, `name`, `email`, `pass`, `location`, `des`) VALUES
(-42, 'SonamTuitions', 'unr3@gmail.com', 'sonamtuitions', 'Ulhasnagar', 'Teacher'),
(8, 'Naresh Bhatia', 'sonamtuitions@gmail.com', 'krishnakutir', 'Ulhasnagar', 'Head'),
(9, 'VMR Tech', 'eureka.vmrtech', 'eureka12345', 'Ulhasnagar', 'Founder'),
(500, 'susanth', 'susanthe2p', 'susanth', '', ''),
(501, 'ambernath', 'ambernath@gmail.com', 'sonamtuitions', 'ambernath', 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
